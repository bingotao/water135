import { Component } from "react";

import Sub1 from "./Sub/Sub1";
import Sub2 from "./Sub/Sub2";
import Sub3 from "./Sub/Sub3";

window.user = {
  id: "test001",
  name: "测试用户",
  privileges: {
    Main: "view",
    Main_Sub1: "view",
    Main_Sub2: "view",
    Main_Sub3: "none"
  }
};

class Main extends Component {
  c_id = "Main";

  constructor(ps) {
    super(ps);
    
    console.log(this.c_id, this.privilege);
  }

  render() {
    console.log(this);
    return (
      <T authObj={this}>
        <div>
          Main
          <Sub1 p_c_id={this.c_id} />
          <Sub2 p_c_id={this.c_id} />
          <Sub3 p_c_id={this.c_id} />
        </div>
      </T>
    );
  }
}

class T extends Component {
  constructor(ps) {
    super(ps);
    let { authObj } = ps;
    let user = window.user;

    if (authObj.props.p_c_id) {
      this.privilege = user.privileges[authObj.props.p_c_id];
      authObj.c_id = `${authObj.props.p_c_id}_${authObj.c_id}`;
    }
    this.privilege = user.privileges[authObj.c_id] || this.privilege;
  }

  render() {
    let { privilege } = this;
    if (privilege && privilege !== "none") return this.props.children;
    else return <div>无权限</div>;
  }
}

export default Main;
