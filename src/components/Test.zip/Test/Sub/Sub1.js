import { Component } from "react";

class Sub1 extends Component {
  c_id = "Sub1";
  render() {
    let { p_c_id } = this.props;
    console.log(this);
    return (
      <div c_id={p_c_id ? `${p_c_id}_${this.c_id}` : this.c_id}>
        Sub1
      </div>
    );
  }
}

export default Sub1;
