import { Component } from "react";

class Sub3 extends Component {
  render() {
    return (
      <div c_id="Sub3">
        <div>Sub3</div>
      </div>
    );
  }
}

export default Sub3;