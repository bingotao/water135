import { Component } from "react";

class Sub2 extends Component {
  render() {
    return (
      <div c_id="Sub2">
        <div>Sub2</div>
      </div>
    );
  }
}

export default Sub2;